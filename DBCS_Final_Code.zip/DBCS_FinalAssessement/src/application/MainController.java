package application;

import java.awt.Desktop;
import java.io.*;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.ResourceBundle;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.FileChooser.ExtensionFilter;

/***
 *The MainController is the FXML-Controller Class.
 */



public class MainController extends Application implements Initializable {
	
	@FXML
    private ComboBox<String> Semester;
    @FXML
    private ComboBox<String> Year;

	File theExcelFile = null;

    @Override
    public void initialize (URL arg0, ResourceBundle arg1) {
//    	if (Semester == null) System.out.println("This is null");
       
    	if (Semester ==null) Semester = new ComboBox<String>();
    	if (Year == null) Year = new ComboBox<String>();
        Semester.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8");
        Year.getItems().addAll("1", "2", "3", "4");
    	
    	
    }

    public void dbToPdf() throws DocumentException, SQLException, IOException {
    	Document d = new Document();
    	PdfWriter.getInstance(d, new FileOutputStream(new File("ThePdfFile.pdf")));
    	d.open();
		d.close();
		Desktop.getDesktop().open(new File("ThePdfFile.pdf"));
    	
    }
    
	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}


   




 
}
		
